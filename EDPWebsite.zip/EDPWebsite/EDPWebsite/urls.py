#This file says look at whatever url the person requested and perform some
#functionality
from django.conf.urls import include, url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from main_page import views
from calibration import views as Cviews
from translation import views as Tviews
from about_us import views as Aviews
from contact_us import views as COviews

#NOTE - Each URL is connected to a view, which is connected to an html response
urlpatterns = [
    url(r'^admin/', admin.site.urls), #r signifies regular expressions,
    url(r'^calibration', Cviews.calibration, name='calibration'),
    url(r'^translation', Tviews.translation),
    url(r'^SignTranslation', Tviews.SignTranslation, name='signtranslation'), #This is called ONLY when the Sign Language to text button is clicked.
    url(r'^SpeechToText', Tviews.SpeechToText, name='speechToText'), #This is called ONLY when the Speech to text button is clicked.
    url(r'^undo', Tviews.undo, name='undo'), #This is called ONLY when the Speech to text button is clicked.
    url(r'^contact_us', COviews.contact_us, name='contact_us'),
    url(r'^about_us', Aviews.about_us, name='about_us'),
    url(r'^', views.landing, name='landing'),

]

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root= settings.STATIC_URL)
    urlpatterns += static(settings.MEDIA_URL, document_root= settings.MEDIA_URL)
