from .models import Video

def test():
    allVideos = Video.objects.all() #This will open the database and extract all of the videos in there into a list
    #There should be only 1 video in there at a time so the list should have only 1 list element inside it

    for video in allVideos:
        if(video.video):
            return video.name
        else:
            return 'test two incomplete'
