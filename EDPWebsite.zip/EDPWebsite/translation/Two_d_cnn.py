#!/usr/bin/env python
# coding: utf-8

# In[8]:


import numpy as np
from numpy import array

from keras.models import Sequential
from keras.layers.core import Dense, Activation
from keras.layers.recurrent import LSTM
from keras.models import load_model
import cv2
from PIL import Image
#from __future__ import absolute_import, division, print_function
import numpy as np
from numpy import array
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import BatchNormalization, Dense, Dropout, Activation, Flatten, Conv2D, MaxPooling2D
import os, cv2, random
import pickle as p


# In[4]:


def twoDCNN(file):
    img1 = cv2.imread(file, cv2.IMREAD_GRAYSCALE)
    img2 = cv2.resize(img1,(108,108))
    img3=img2.reshape(108,108,1)
    X=np.asarray(img3, dtype=np.int32)
    X=X.reshape(-1,108,108,1)
    X=np.divide(X,255)
    model= Sequential()
    model.add( Conv2D(32,(3,3), input_shape = X.shape[1:]) )#input (108,108,1)
    model.add(Activation("relu"))
    model.add( Conv2D(32, (3,3)) )
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2,2)))

    model.add(Conv2D(32,(3,3)))
    model.add(Activation("relu"))
    model.add(Conv2D(32,(3,3)))
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(BatchNormalization())

    model.add(Conv2D(32,(3,3)))
    model.add(Activation("relu"))
    model.add(Conv2D(32,(3,3)))
    model.add(Activation("relu"))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(BatchNormalization())
    model.add(Flatten())
    model.add(Dense(units=128))
    model.add(Dropout(0.22))
    model.add(Dense(units=3))
    model.add(Activation('softmax'))
    model.load_weights("C:\\Users\\Jon\\Documents\\Biomedical Engineering - IC\\2. letnik\\EDP\\EDPWebsite_V11\\EDPWebsite\\translation\\2dcnn.h5")
    pred=model.predict(X, batch_size=1, verbose=1)[0]
    if pred[0]>pred[1] and pred[0]>pred[2] and pred[0]>=0.4:
        #print("Angry")
        sign = "Angry"
        #print(pred)
    if pred[1]>pred[0] and pred[1]>pred[2] and pred[1]>=0.4:
        #print("Hungry")
        sign = "Hungry"
        #print(pred)
    if pred[2]>pred[0] and pred[2]>pred[1] and pred[2]>=0.4:
        #print("What")
        sign = "What"
        #print(pred)
    if pred[0]<0.4 and pred[1]<0.4 and pred[2]<0.4:
        #rint("No sign")
        sign = "No sign"
    return sign

# In[ ]:
