from django.db import models

# Create your models here.
class Video(models.Model):
    name = models.CharField(max_length = 500) # stores the name of the video
    video = models.FileField() #Note - i am storing the pathway to the video and not the video itself

    translated_word = models.CharField(max_length = 40) #would store the word translated from the hand gesture recognition group
    eyebrows = models.CharField(max_length = 20) #would store whether or not eyebrows are raised. 3 possibilities: raised, lowered, neutral
    head_movement = models.CharField(max_length = 20) #would store the head movement that was detected. 2 possibilities - shaking and neutral

    #function to see what has been stored so far for each variable
    def __str__(self):
        return "Name: " + self.name + "translated word: " + self.translated_word + " Eyebrows: " + self.eyebrows + " Head movement: " + self.head_movement
