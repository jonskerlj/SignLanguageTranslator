# ENSURE THAT shape_predictor_68_face_landmarks.dat FILE IS IN THE SAME
# DIRECTORY AS THE CODE, OR THAT PATH IS CHANGED

# ENSURE THAT ALL OTHER SCRIPTS ARE IN SAME DIRECTORY AS CODE, OR THAT PATH IS
# CHANGED



def SignMe():

    from . import facial_landmarks_video
    from . import Pre_Processing
    from . import Two_d_cnn
    from . import Video_taking
    #directoryName = 'C:\\Users\\Jon\\Documents\\Biomedical Engineering - IC\\2. letnik\\EDP\\EDPWebsite_V11\\EDPWebsite\\tanslation\\InputVideo'
    Video_taking.Video_taking1("video")
    shapePredictor = 'C:\\Users\\Jon\\Documents\\Biomedical Engineering - IC\\2. letnik\\EDP\\EDPWebsite_V11\\EDPWebsite\\translation\\shape_predictor_68_face_landmarks.dat'

    # name of video file may be different - currently set to test.mp4 in pre-processing program
    videoFile =  'video.avi'

    facialCue = facial_landmarks_video.faceMoves(shapePredictor, videoFile)

    print(facialCue)
    Pre_Processing.processVideo(videoFile, 'C:\\Users\\Jon\\Documents\\Biomedical Engineering - IC\\2. letnik\\EDP\\EDPWebsite_V11\\EDPWebsite\\translation\\MHI_image', 4, 108, 1)
    #facial_cue : headshake, eyebrow_raised, frowning
    sign = Two_d_cnn.twoDCNN("C:\\Users\\Jon\\Documents\\Biomedical Engineering - IC\\2. letnik\\EDP\\EDPWebsite_V11\\EDPWebsite\\translation\\MHI_image.jpg")
    print(facialCue)
    if facialCue == 'shakeNeutral':
        translation = 'not' + sign
        #print(translation)
        return translation

    elif facialCue == 'neutralRaised':
        translation = sign + '?'
        #print(translation)
        return translation

    elif facialCue == 'shakeRaised':
        translation = 'not' + sign + '?'
        #print(translation)
        return translation

    elif sign == 'What' and facialCue == 'neutralFrown':
        translation = sign + '?'
        #print(translation)
        return translation
    else:
        translation = sign
        #print(translation)
        return translation
