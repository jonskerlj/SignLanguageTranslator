import time
from django.shortcuts import render

from django.http import HttpResponse
from .models import Video
from . import testingpy
from . import testingDatabase
from . import speechToText
from . import main_code
bigList = [] #empty list containing all the translations made when Speech to Text button is clicked

#This function is called when a button isn't clicked - simply renders the html page
def translation(request):
    return render(request, 'translation.html')

#This function is called only when the sign language to text button is clicked.
def SignTranslation(request):
    data = main_code.SignMe()
    print(data)
    bigList.append(data)
    return render(request, 'translation.html', {'test': bigList});

#This function is called only when the speech to text button is clicked
def SpeechToText(request):
    data = speechToText.GetText()
    bigList.append(data)
    return render(request, 'translation.html', {'test': bigList});

#This function is called only when the undo button is clicked
def undo(request):
    if(len(bigList)):
        del bigList[-1] #this deletes the last element in the bigList list - i.e. undoes the last translation
    return render(request, 'translation.html', {'test': bigList});
