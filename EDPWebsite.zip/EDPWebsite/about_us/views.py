from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse


def about_us(request):
    return render(request, 'about_us.html');

def index(request):
    return HttpResponse('<h1>This is the about us page</h1>')
