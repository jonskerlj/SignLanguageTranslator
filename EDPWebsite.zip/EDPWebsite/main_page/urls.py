from django.conf.urls import url
from . import views #the dot means look at the current directory i am in

urlpatterns = [
    # /main_page/
    url(r'^$', views.index, name='index'),
    # Note: ^ represents beginning and $ represents the end
    # /main_page/calibration/
    #url(r'^(?P<page_name>[c][a][a-z]+)/$', views.calibrate, name = 'calibrate'),
]
