from django.contrib import admin

from .models import Picture #Imports the class picture from itself

#The code below makes the table for Picture appear in the admin page online
admin.site.register(Picture)
