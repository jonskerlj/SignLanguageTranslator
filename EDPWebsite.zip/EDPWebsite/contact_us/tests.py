from django.test import TestCase
#can creata multiple tests to ensure that i dont have any bugs in my code
# Create your tests here.
