from django.db import models
#blueprint for your database
# Create your models here.
